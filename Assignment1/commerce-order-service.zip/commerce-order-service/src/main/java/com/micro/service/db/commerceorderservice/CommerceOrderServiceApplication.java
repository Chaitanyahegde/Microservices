package com.micro.service.db.commerceorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommerceOrderServiceApplication.class, args);
	}

}
