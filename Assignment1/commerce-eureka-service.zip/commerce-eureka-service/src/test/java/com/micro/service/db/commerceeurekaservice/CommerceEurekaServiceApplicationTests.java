package com.micro.service.db.commerceeurekaservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CommerceEurekaServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
