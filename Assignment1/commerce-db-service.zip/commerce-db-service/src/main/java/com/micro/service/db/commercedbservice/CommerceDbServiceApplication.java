package com.micro.service.db.commercedbservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceDbServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommerceDbServiceApplication.class, args);
	}

}
